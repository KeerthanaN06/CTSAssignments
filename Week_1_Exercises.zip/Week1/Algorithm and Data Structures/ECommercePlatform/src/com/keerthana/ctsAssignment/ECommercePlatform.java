package com.keerthana.ctsAssignment;

public class ECommercePlatform {
    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Desk Chair", "Furniture"),
            new Product("4", "Monitor", "Electronics"),
            new Product("5", "Coffee Table", "Furniture")
        };

        // Linear search
        Product result1 = LinearSearch.linearSearch(products, "Monitor");
        System.out.println("Linear Search Result: " + (result1 != null ? result1 : "Product not found"));

        // Binary search
        Product result2 = BinarySearch.binarySearch(products, "Monitor");
        System.out.println("Binary Search Result: " + (result2 != null ? result2 : "Product not found"));
    }
}
