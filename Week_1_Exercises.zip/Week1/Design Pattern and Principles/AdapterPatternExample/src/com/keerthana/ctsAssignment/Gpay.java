package com.keerthana.ctsAssignment;

public class Gpay {
	private String name = "Gpay";
	
	public void doPayment(double amount) {
		System.out.print(amount+" is transferred from "+ name +"!");
	}
}
