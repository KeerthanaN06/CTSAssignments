package com.keerthana.ctsAssignment;
public class Paypal {
	private String name = "PayPal"; 
	public void makePayment(double amount) {
		System.out.print(amount+" is transferred from "+ name + "!");
	}
}
