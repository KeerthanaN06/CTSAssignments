package com.keerthana.ctsAssignment;


public class PhonepeAdapter implements PaymentProcessor {
	private Phonepe phonepe;
	
	
	public PhonepeAdapter(Phonepe phonepe) {
		this.phonepe = phonepe;
	}
	@Override
	public void processPayment(double amount) {
		// TODO Auto-generated method stub
		phonepe.sendPayment(amount);
		
	}
}
