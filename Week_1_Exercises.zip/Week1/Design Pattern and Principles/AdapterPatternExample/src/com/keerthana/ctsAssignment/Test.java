package com.keerthana.ctsAssignment;
public class Test {
    public static void main(String[] args) {
    	
        PaymentProcessor paypal = new PaypalAdapter(new Paypal());
        paypal.processPayment(100.0);

        PaymentProcessor gpay = new GpayAdapter(new Gpay());
        gpay.processPayment(200.0);

        PaymentProcessor phonepe = new PhonepeAdapter(new Phonepe());
        phonepe.processPayment(300.0);
    }
}

