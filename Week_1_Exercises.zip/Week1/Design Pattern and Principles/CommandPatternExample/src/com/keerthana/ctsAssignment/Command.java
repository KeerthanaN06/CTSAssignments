package com.keerthana.ctsAssignment;

public interface Command {
    void execute();
}