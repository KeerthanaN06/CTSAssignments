package com.keerthana.ctsAssignment;
public interface Notifier {
	void send(String message);
}