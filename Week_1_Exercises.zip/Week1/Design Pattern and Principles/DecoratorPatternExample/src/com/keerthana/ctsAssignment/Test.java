package com.keerthana.ctsAssignment;

public class Test {
    public static void main(String[] args) {
        // Base notifier
        Notifier notifier = new EmailNotifier();

        // Adding SMS notification functionality
        notifier = new SMSNotifierDecorator(notifier);

        // Adding Slack notification functionality
        notifier = new SlackNotifierDecorator(notifier);

        // Sending notification
        notifier.send("This is a test notification.");
    }
}
