package com.keerthana.ctsAssignment;

public interface CustomerRepository {
    Customer findCustomerById(String id);
}