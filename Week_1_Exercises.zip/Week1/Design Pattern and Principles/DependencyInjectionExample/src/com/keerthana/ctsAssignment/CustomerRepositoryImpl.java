package com.keerthana.ctsAssignment;

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        // In a real application, this method would query the database.
        return new Customer(id, "John Doe");
    }
}