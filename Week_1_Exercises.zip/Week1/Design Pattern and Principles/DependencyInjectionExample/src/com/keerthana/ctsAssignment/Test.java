package com.keerthana.ctsAssignment;

public class Test {
    public static void main(String[] args) {
        // Create a CustomerRepository
        CustomerRepository repository = new CustomerRepositoryImpl();

        // Inject the repository into CustomerService
        CustomerService service = new CustomerService(repository);

        // Find a customer
        Customer customer = service.getCustomer("1");
        System.out.println("Customer ID: " + customer.getId());
        System.out.println("Customer Name: " + customer.getName());
    }
}

