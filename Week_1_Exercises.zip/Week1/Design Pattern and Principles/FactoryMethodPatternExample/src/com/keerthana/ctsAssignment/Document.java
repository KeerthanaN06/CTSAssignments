package com.keerthana.ctsAssignment;

public interface Document {
	 void open();
	 void close();
}
