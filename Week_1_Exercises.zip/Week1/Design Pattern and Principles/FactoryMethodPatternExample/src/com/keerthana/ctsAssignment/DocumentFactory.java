package com.keerthana.ctsAssignment;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
