package com.keerthana.ctsAssignment;


public class Test{
    public static void main(String[] args) {
        // Create a Student
        Student student = new Student("1", "John Doe", "A");

        // Create a StudentView
        StudentView view = new StudentView();

        // Create a StudentController
        StudentController controller = new StudentController(student, view);

        // Display initial details
        controller.updateView();

        // Update student details
        controller.setStudentName("Jane Doe");
        controller.setStudentGrade("B");

        // Display updated details
        controller.updateView();
    }
}