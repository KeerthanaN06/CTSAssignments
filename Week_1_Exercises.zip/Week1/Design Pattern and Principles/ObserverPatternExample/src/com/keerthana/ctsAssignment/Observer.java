package com.keerthana.ctsAssignment;

public interface Observer {
    void update(double stockPrice);
}
