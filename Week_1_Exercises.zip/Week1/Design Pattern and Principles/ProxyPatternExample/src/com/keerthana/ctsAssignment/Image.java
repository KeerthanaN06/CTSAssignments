package com.keerthana.ctsAssignment;

public interface Image {
	void display();
}

