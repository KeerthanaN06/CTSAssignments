package com.keerthana.ctsAssignment;


public interface PaymentStrategy {
    void pay(double amount);
}